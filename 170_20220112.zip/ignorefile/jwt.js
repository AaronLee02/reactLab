let jwtObj = {};
jwtObj.secret = "react200"
module.exports = jwtObj